from django.apps import AppConfig


class NotifyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.notify'

    def ready(self):
        import apps.notify.signals  # noqa: F401