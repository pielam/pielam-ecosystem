# backend/apps/ponno/views/brand_list.py

import hashlib

from django.core.cache import cache
from django.core.paginator import Paginator, InvalidPage
from django.http import Http404
from django.shortcuts import render
from django.db.models import Q

from apps.ponno.models.brand import Brand


CACHE_TTL    = 60   # seconds
BRANDS_PER_PAGE = 24


def BrandListView(request):
    """
    Brand List View
    - Lists all active brands with search + filter
    - Highlights a single brand when ?brand=<slug> is passed
      (coming from the discovery engine filter chips)
    - Cached per unique URL to handle high traffic
    """

    # ── Params ───────────────────────────────────────────────────────
    query       = request.GET.get('q',      '').strip()[:100]
    brand_slug  = request.GET.get('brand',  '').strip()[:80]
    filter_type = request.GET.get('type',   'all').strip()   # all | verified | featured | trending
    sort_by     = request.GET.get('sort',   'popular').strip()
    page_number = request.GET.get('page',   1)

    VALID_SORTS = {'popular', 'newest', 'name_asc', 'name_desc'}
    if sort_by not in VALID_SORTS:
        sort_by = 'popular'

    # ── Cache key ────────────────────────────────────────────────────
    raw_key   = f"brandlist:{query}:{brand_slug}:{filter_type}:{sort_by}:{page_number}"
    cache_key = 'brand_list_' + hashlib.md5(raw_key.encode()).hexdigest()

    cached = cache.get(cache_key)
    if cached:
        return render(request, 'ponno/brand_list.html', cached)

    # ── Base queryset ────────────────────────────────────────────────
    brands = (
        Brand.objects
        .active_brands()
        .only(
            'pk', 'brand_name', 'brand_slug', 'brand_tagline',
            'brand_logo', 'brand_type', 'country_of_origin',
            'is_verified', 'is_featured', 'is_trending', 'is_official',
            'is_trusted', 'product_count', 'view_count',
            'verification_status', 'popularity_score',
        )
    )

    # ── Highlight a specific brand (coming from filter chip) ─────────
    highlighted_brand = None
    if brand_slug:
        try:
            highlighted_brand = brands.get(brand_slug=brand_slug)
        except Brand.DoesNotExist:
            pass

    # ── Search ───────────────────────────────────────────────────────
    if query:
        brands = brands.filter(
            Q(brand_name__icontains=query) |
            Q(brand_description__icontains=query) |
            Q(company_name__icontains=query) |
            Q(brand_tagline__icontains=query)
        )

    # ── Type filter ──────────────────────────────────────────────────
    if filter_type == 'verified':
        brands = brands.filter(is_verified=True)
    elif filter_type == 'featured':
        brands = brands.filter(is_featured=True)
    elif filter_type == 'trending':
        brands = brands.filter(is_trending=True)
    elif filter_type == 'official':
        brands = brands.filter(is_official=True)

    # ── Sort ─────────────────────────────────────────────────────────
    SORT_MAP = {
        'popular':   ['-popularity_score', '-product_count'],
        'newest':    ['-brand_created_at'],
        'name_asc':  ['brand_name'],
        'name_desc': ['-brand_name'],
    }
    brands = brands.order_by(*SORT_MAP[sort_by])

    # ── Stats (cached separately, longer TTL) ────────────────────────
    stats_key = 'brand_list_stats'
    stats     = cache.get(stats_key)
    if stats is None:
        all_active = Brand.objects.active_brands()
        stats = {
            'total':    all_active.count(),
            'verified': all_active.filter(is_verified=True).count(),
            'featured': all_active.filter(is_featured=True).count(),
            'trending': all_active.filter(is_trending=True).count(),
        }
        cache.set(stats_key, stats, 120)

    # ── Paginate ─────────────────────────────────────────────────────
    paginator = Paginator(brands, BRANDS_PER_PAGE)
    try:
        page_obj = paginator.get_page(page_number)
    except InvalidPage:
        raise Http404

    # ── Format ───────────────────────────────────────────────────────
    formatted_brands = [
        {
            'id':           brand.pk,
            'name':         brand.brand_name,
            'slug':         brand.brand_slug,
            'tagline':      brand.brand_tagline or '',
            'logo':         brand.logo_url,
            'type':         brand.brand_type,
            'country':      brand.country_of_origin or '',
            'is_verified':  brand.is_verified,
            'is_featured':  brand.is_featured,
            'is_trending':  brand.is_trending,
            'is_official':  brand.is_official,
            'is_trusted':   brand.is_trusted,
            'product_count': brand.product_count,
            'view_count':   brand.view_count,
            'brand_url':    brand.brand_url,
            'highlighted':  highlighted_brand and brand.pk == highlighted_brand.pk,
        }
        for brand in page_obj
    ]

    sort_options = [
        {'value': 'popular',   'label': 'Most Popular',  'active': sort_by == 'popular'},
        {'value': 'newest',    'label': 'Newest First',  'active': sort_by == 'newest'},
        {'value': 'name_asc',  'label': 'Name A → Z',   'active': sort_by == 'name_asc'},
        {'value': 'name_desc', 'label': 'Name Z → A',   'active': sort_by == 'name_desc'},
    ]

    filter_tabs = [
        {'value': 'all',      'label': 'All',      'count': stats['total'],    'active': filter_type == 'all'},
        {'value': 'verified', 'label': 'Verified', 'count': stats['verified'], 'active': filter_type == 'verified'},
        {'value': 'featured', 'label': 'Featured', 'count': stats['featured'], 'active': filter_type == 'featured'},
        {'value': 'trending', 'label': 'Trending', 'count': stats['trending'], 'active': filter_type == 'trending'},
    ]

    context = {
        'brands':             formatted_brands,
        'page_obj':           page_obj,
        'query':              query,
        'brand_slug':         brand_slug,
        'highlighted_brand':  highlighted_brand,
        'current_sort':       sort_by,
        'current_filter':     filter_type,
        'sort_options':       sort_options,
        'filter_tabs':        filter_tabs,
        'total_count':        paginator.count,
        'stats':              stats,
    }

    cache.set(cache_key, context, CACHE_TTL)
    return render(request, 'ponno/brand_list.html', context)