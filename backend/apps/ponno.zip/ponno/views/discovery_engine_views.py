"""
apps/ponno/views/discovery_engine.py
=====================================
Discovery Engine View  —  Enterprise Edition (Upgraded)

What changed vs the previous version
──────────────────────────────────────
UPGRADE-1   All filter / sort logic delegated to FilterPipeline
            (filter_products.py).  The view only handles HTTP plumbing;
            FilterPipeline owns the queryset pipeline.

UPGRADE-2   All badge resolution delegated to resolve_badges_from_dict
            (product_badges.py).  _format_products() no longer contains
            any badge logic.

UPGRADE-3   FeedEngine (feed_algorithm.py) used for both scoring paths:
            • rank_dicts()   → formatted-dict feed (newest / popular)
            • explain_score_dict() available for debug/admin endpoints

UPGRADE-4   FilterParams.from_request() replaces manual GET parsing in
            every branch.  FilterMeta.applied_filters drives the
            "active filters" UI hint in context.

UPGRADE-5   build_tab_options() added to context so the template can
            render the tab bar without hard-coding slugs.

UPGRADE-6   profile_view_log recorded via ProfileViewLog model when a
            user views another user's product (seller != viewer).

UPGRADE-7   _format_products() emits all fields the template actually
            reads — no missing keys, no silent AttributeErrors.

UPGRADE-8   natural_sort_pks() from filter_products.py replaces the
            local duplicate.

UPGRADE-9   All cache wrappers (safe get/set/add/delete/incr) preserved
            and used consistently.

UPGRADE-10  ETag, Cache-Control, rate-limit and stampede-guard logic
            preserved intact from previous enterprise version.

UPGRADE-11  Template-compatibility audit:
            • 'image' key now uses product.image_url (full URL) so the
              template <img src="{{ product.image }}"> never breaks.
            • 'rating' cast to int so {% if forloop.counter <= product.rating %}
              works correctly in the star-loop.
            • 'page_obj' guaranteed non-None on every code path so the
              inline JS {{ page_obj.number }} / {{ page_obj.paginator.num_pages }}
              never raises a TemplateSyntaxError.
            • getCookie() JS helper injected once in context so wishlist /
              follow AJAX calls work without ReferenceError.
            • suggested_dealers annotated with .profile_name attribute
              via a lightweight wrapper so the sidebar
              {{ dealer.profileinfo.profile_name }} never KeyErrors.
            • 'brand_logo' and 'seller_photo' always resolve to full
              absolute-or-root-relative URLs (never raw FileField paths).

Architecture overview
─────────────────────
Request
  │
  ├─ Rate limit  (Redis sliding window)        → 429 if exceeded
  │
  ├─ ETag check                                → 304 if unchanged
  │
  ├─ FilterParams.from_request(request)        parse all params
  │
  ├─ Load fragments (brands/cats/subcats)      fragment cache
  │
  ├─ FilterPipeline.run(base_qs, params)       all filters + sort
  │
  ├─ Sort path:
  │     name_az      → natural_sort_pks()  (PKs, then Case/When)
  │     discount      → DB ORDER BY
  │     explicit      → DB ORDER BY
  │     feed sorts   → FeedEngine.rank_dicts() + two-tier cache
  │
  ├─ Inject per-user wishlist state            Redis → DB fallback
  │
  ├─ Async view-log dispatch                   Celery → Redis INCR
  │
  └─ Render + ETag / Cache-Control headers

Cache key namespace
───────────────────
  de:brands               fragment: active brand list
  de:cats                 fragment: active category list
  de:subcats              fragment: active sub-category list
  de:total                fragment: total product count
  de:brand_cat_map        fragment: brand→[category slugs] map
  de:brand_subcat_map     fragment: brand→[subcat slugs] map
  de:base:<hash>          Tier-1 feed: full scored product list
  de:page:<hash>          Tier-2 feed: paginated slice
  wl:<user_pk>            per-user wishlist UUID set
  rl:ip:<ip>              rate limit counter (anonymous)
  rl:u:<user_pk>          rate limit counter (authenticated)
  lock:<key>              stampede guard lock
"""

from __future__ import annotations

import hashlib
import logging
import re
import time
from decimal import Decimal

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.core.cache import cache
from django.core.paginator import Paginator
from django.db.models import Case, Count, IntegerField, Q, Value, When
from django.http import HttpRequest, HttpResponse
from django.shortcuts import render
from django.utils import timezone
from django.utils.html import escape

from apps.ponno.feed_algorithm import (
    FeedEngine,
    TAB_FILTER_SLUGS,
    get_tab_filter_map,
    invalidate_user_affinity,
)
from apps.ponno.filter_products import (
    EXPLICIT_SORT_BYPASSES,
    SORT_MAP,
    FilterParams,
    FilterPipeline,
    build_sort_options,
    build_tab_options,
    natural_sort_pks,
)
from apps.ponno.models.brand import Brand
from apps.ponno.models.category import Category
from apps.ponno.models.product import Product
from apps.ponno.models.sub_category import SubCategory
from apps.ponno.product_badges import attach_badges_to_products, resolve_badges_from_dict

logger = logging.getLogger(__name__)
User   = get_user_model()


# ═══════════════════════════════════════════════════════════════════
# ██  TUNEABLE CONSTANTS
# ═══════════════════════════════════════════════════════════════════

PRODUCTS_PER_PAGE  = getattr(settings, 'DE_PRODUCTS_PER_PAGE',  20)
TTL_FEED_PAGE      = getattr(settings, 'DE_TTL_FEED_PAGE',       60)
TTL_FEED_BASE      = getattr(settings, 'DE_TTL_FEED_BASE',      120)
TTL_FRAGMENT_LIST  = getattr(settings, 'DE_TTL_FRAGMENT_LIST',  180)
TTL_TOTAL_COUNT    = getattr(settings, 'DE_TTL_TOTAL_COUNT',    120)
TTL_FILTER_BUTTONS = getattr(settings, 'DE_TTL_FILTER_BUTTONS', 120)
TTL_WISHLIST       = getattr(settings, 'DE_TTL_WISHLIST',       300)
TTL_LOCK           = getattr(settings, 'DE_TTL_LOCK',            10)

_RL_WINDOW_S    = 60
_RL_ANON_LIMIT  = 120
_RL_AUTH_LIMIT  = 600

_VIEWCNT_PREFIX  = 'de:viewcnt'
_WISHLIST_PREFIX = 'wl'

# Columns the ORM fetches — keeps DB rows narrow
PRODUCT_FIELDS = [
    'pk', 'product_id', 'slug', 'sku',
    'product_title', 'product_name', 'short_description',
    'brand_price', 'selling_price', 'final_price', 'discount_percentage',
    'image', 'video_url', 'free_shipping',
    'view_count', 'rating_average', 'review_count', 'total_sales',
    'wishlist_count',
    'stock', 'stock_status', 'low_stock_threshold',
    'is_featured', 'is_verified', 'is_trending',
    'product_condition',
    'brand_id', 'category_id', 'sub_category_id', 'dealer_id',
    'created_at',
]

# ── JS helper injected into every page (needed by wishlist / follow AJAX) ──
_GET_COOKIE_JS = """
<script>
function getCookie(name) {
  const v = document.cookie.match('(^|;)\\\\s*' + name + '\\\\s*=\\\\s*([^;]+)');
  return v ? v.pop() : '';
}
</script>
""".strip()


# ═══════════════════════════════════════════════════════════════════
# ██  SAFE CACHE WRAPPERS  (graceful Redis degradation)
# ═══════════════════════════════════════════════════════════════════

def _safe_cache_get(key: str):
    try:
        return cache.get(key)
    except Exception as exc:
        logger.warning('cache.get failed key=%s err=%s', key, exc)
        return None


def _safe_cache_set(key: str, value, ttl: int) -> None:
    try:
        cache.set(key, value, ttl)
    except Exception as exc:
        logger.warning('cache.set failed key=%s err=%s', key, exc)


def _safe_cache_add(key: str, value, ttl: int) -> bool:
    try:
        return bool(cache.add(key, value, ttl))
    except Exception as exc:
        logger.warning('cache.add failed key=%s err=%s', key, exc)
        return False


def _safe_cache_delete(key: str) -> None:
    try:
        cache.delete(key)
    except Exception as exc:
        logger.warning('cache.delete failed key=%s err=%s', key, exc)


def _safe_cache_incr(key: str) -> None:
    try:
        cache.incr(key)
    except Exception:
        try:
            cache.set(key, 1, TTL_FEED_BASE)
        except Exception as exc:
            logger.warning('cache.incr/set failed key=%s err=%s', key, exc)


# ═══════════════════════════════════════════════════════════════════
# ██  CACHE KEY HELPERS
# ═══════════════════════════════════════════════════════════════════

def _ck(*parts) -> str:
    raw = ':'.join(str(p) for p in parts)
    return 'de:' + hashlib.blake2b(raw.encode(), digest_size=10).hexdigest()


def _feed_base_key(user_id, query, filter_slug, sort_by) -> str:
    return _ck('base', user_id, query, filter_slug, sort_by)


def _feed_page_key(user_id, query, filter_slug, sort_by,
                   page, min_p, max_p, in_stock) -> str:
    return _ck('page', user_id, query, filter_slug, sort_by,
               page, min_p, max_p, in_stock)


# ═══════════════════════════════════════════════════════════════════
# ██  STAMPEDE GUARD
# ═══════════════════════════════════════════════════════════════════

def _lock(key: str) -> bool:
    return _safe_cache_add(f'lock:{key}', 1, TTL_LOCK)


def _unlock(key: str) -> None:
    _safe_cache_delete(f'lock:{key}')


# ═══════════════════════════════════════════════════════════════════
# ██  RATE LIMITER
# ═══════════════════════════════════════════════════════════════════

def _check_rate_limit(request: HttpRequest) -> bool:
    """Sliding-window counter in Redis. Fails open when Redis is unavailable."""
    try:
        if request.user.is_authenticated:
            key   = f'rl:u:{request.user.pk}'
            limit = _RL_AUTH_LIMIT
        else:
            ip  = (
                request.META.get('HTTP_X_FORWARDED_FOR', '')
                            .split(',')[0].strip()
                or request.META.get('REMOTE_ADDR', 'unknown')
            )
            key   = f'rl:ip:{ip}'
            limit = _RL_ANON_LIMIT

        count = cache.get(key) or 0
        if count >= limit:
            return False
        cache.get_or_set(key, 0, _RL_WINDOW_S)
        cache.incr(key)
        return True
    except Exception as exc:
        logger.warning('rate_limit check failed: %s', exc)
        return True  # fail open


# ═══════════════════════════════════════════════════════════════════
# ██  ETAG / CACHE-CONTROL
# ═══════════════════════════════════════════════════════════════════

def _build_etag(products: list[dict], user_pk) -> str:
    ids = ','.join(str(p.get('uuid', p.get('id', ''))) for p in products)
    raw = f'{ids}:{user_pk}'
    return hashlib.md5(raw.encode(), usedforsecurity=False).hexdigest()  # noqa: S324


def _set_cache_headers(response: HttpResponse, etag: str, user) -> None:
    response['ETag'] = f'"{etag}"'
    response['Vary'] = 'Accept-Encoding, X-Requested-With'
    if getattr(user, 'is_authenticated', False):
        response['Cache-Control'] = f'private, max-age={TTL_FEED_PAGE}'
    else:
        response['Cache-Control'] = (
            f'public, max-age=30, s-maxage={TTL_FEED_PAGE}, stale-while-revalidate=15'
        )


# ═══════════════════════════════════════════════════════════════════
# ██  ASYNC VIEW-LOG DISPATCH
# ═══════════════════════════════════════════════════════════════════

def _dispatch_view_logs(product_db_ids: list[int], user_pk) -> None:
    """Celery primary, Redis INCR fallback."""
    if not product_db_ids:
        return
    try:
        from apps.ponno.tasks import record_product_views_task  # noqa: PLC0415
        record_product_views_task.delay(product_db_ids, user_pk)
    except Exception as exc:
        logger.debug('Celery unavailable for view logging: %s', exc)
        for pid in product_db_ids:
            _safe_cache_incr(f'{_VIEWCNT_PREFIX}:{pid}')


# ═══════════════════════════════════════════════════════════════════
# ██  PROFILE VIEW LOG  (UPGRADE-6)
# ═══════════════════════════════════════════════════════════════════

def _record_profile_views(formatted_products: list[dict], viewer) -> None:
    """
    For each product on this page whose seller is not the viewer,
    upsert a ProfileViewLog row (one row per viewer × profile_user).
    Silently ignored if the model isn't wired yet.
    """
    if not viewer or not getattr(viewer, 'is_authenticated', False):
        return
    try:
        from apps.customer.models.account import ProfileViewLog  # noqa: PLC0415
        seen_dealer_ids: set[int] = set()
        for p in formatted_products:
            dealer_id = p.get('dealer_id')
            if not dealer_id or dealer_id == viewer.pk:
                continue
            if dealer_id in seen_dealer_ids:
                continue
            seen_dealer_ids.add(dealer_id)

            profile_user = User.objects.filter(pk=dealer_id).first()
            if not profile_user:
                continue

            obj, created = ProfileViewLog.objects.get_or_create(
                profile_user=profile_user,
                viewer=viewer,
                defaults={
                    'viewed_at': timezone.now(),
                    'ip_address': None,
                }
            )
            if not created:
                obj.viewed_at = timezone.now()
                obj.save(update_fields=['viewed_at'])
    except Exception:
        logger.debug('_record_profile_views failed', exc_info=True)


# ═══════════════════════════════════════════════════════════════════
# ██  WISHLIST CACHE
# ═══════════════════════════════════════════════════════════════════

def _get_wishlisted_ids(user) -> set[str]:
    """Per-user wishlist UUID set. Redis-cached; DB fallback on cold miss."""
    if not user or not getattr(user, 'is_authenticated', False):
        return set()

    key    = f'{_WISHLIST_PREFIX}:{user.pk}'
    cached = _safe_cache_get(key)
    if cached is not None:
        return cached

    try:
        ids = set(
            str(uid)
            for uid in user.wishlist_items
                              .values_list('product__product_id', flat=True)
        )
    except Exception:
        ids = set()

    _safe_cache_set(key, ids, TTL_WISHLIST)
    return ids


def invalidate_wishlist_cache(user_pk: int) -> None:
    _safe_cache_delete(f'{_WISHLIST_PREFIX}:{user_pk}')


# ═══════════════════════════════════════════════════════════════════
# ██  BATCH DEALER PRODUCT COUNTS
# ═══════════════════════════════════════════════════════════════════

def _batch_dealer_product_counts(product_list: list) -> dict[int, int]:
    dealer_ids = {p.dealer_id for p in product_list if p.dealer_id}
    if not dealer_ids:
        return {}
    rows = (
        Product.objects
        .filter(dealer_id__in=dealer_ids, is_active=True)
        .values('dealer_id')
        .annotate(cnt=Count('pk'))
    )
    return {row['dealer_id']: row['cnt'] for row in rows}


# ═══════════════════════════════════════════════════════════════════
# ██  MEDIA URL HELPER
# ═══════════════════════════════════════════════════════════════════

def _media(path: str | None) -> str | None:
    """
    Turn a bare FileField path (e.g. 'products/img.jpg') into a
    root-relative URL ('/media/products/img.jpg').
    Already-absolute paths (http/https) are returned unchanged.
    None / empty → None.
    """
    if not path:
        return None
    s = str(path)
    if s.startswith(('http://', 'https://', '/', 'data:')):
        return s
    media_url = getattr(settings, 'MEDIA_URL', '/media/')
    if not media_url.endswith('/'):
        media_url += '/'
    return media_url + s.lstrip('/')


# ═══════════════════════════════════════════════════════════════════
# ██  FRAGMENT CACHE HELPERS
# ═══════════════════════════════════════════════════════════════════

def _get_active_brands() -> list[dict]:
    key  = 'de:brands'
    data = _safe_cache_get(key)
    if data is not None:
        return data

    got_lock = _lock(key)
    if not got_lock:
        return _safe_cache_get(key) or []

    try:
        qs = (
            Brand.objects
            .active_brands()
            .annotate(
                live_product_count=Count(
                    'products',
                    filter=Q(products__is_active=True, products__deleted_at__isnull=True),
                    distinct=True,
                ),
                live_category_count=Count(
                    'products__category',
                    filter=Q(products__is_active=True, products__deleted_at__isnull=True),
                    distinct=True,
                ),
            )
            .values('pk', 'brand_name', 'brand_slug', 'brand_logo',
                    'is_featured', 'live_product_count', 'live_category_count')
            .order_by('-live_product_count')
        )
        data = []
        for row in qs:
            lp = row['brand_logo']
            data.append({
                'pk':             row['pk'],
                'brand_name':     row['brand_name'],
                'brand_slug':     row['brand_slug'],
                'brand_logo':     lp,
                'is_featured':    row['is_featured'],
                'product_count':  row['live_product_count'],
                'category_count': row['live_category_count'],
                # UPGRADE-11: full URL so sidebar <img src="{{ b.brand_logo_url }}"> works
                'brand_logo_url': _media(lp),
            })
        _safe_cache_set(key, data, TTL_FRAGMENT_LIST)
        return data
    finally:
        _unlock(key)


def _get_active_categories() -> list[dict]:
    key  = 'de:cats'
    data = _safe_cache_get(key)
    if data is not None:
        return data

    got_lock = _lock(key)
    if not got_lock:
        return _safe_cache_get(key) or []

    try:
        qs = (
            Category.objects
            .active_categories()
            .annotate(
                live_product_count=Count(
                    'products',
                    filter=Q(products__is_active=True, products__deleted_at__isnull=True),
                    distinct=True,
                )
            )
            .values('pk', 'category_name', 'category_slug', 'is_featured',
                    'path', 'level', 'live_product_count')
            .order_by('-live_product_count')
        )
        data = [
            {
                'pk':            r['pk'],
                'category_name': r['category_name'],
                'category_slug': r['category_slug'],
                'is_featured':   r['is_featured'],
                'path':          r['path'],
                'level':         r['level'],
                'product_count': r['live_product_count'],
            }
            for r in qs
        ]
        _safe_cache_set(key, data, TTL_FRAGMENT_LIST)
        return data
    finally:
        _unlock(key)


def _get_active_sub_categories() -> list[dict]:
    key  = 'de:subcats'
    data = _safe_cache_get(key)
    if data is not None:
        return data

    got_lock = _lock(key)
    if not got_lock:
        return _safe_cache_get(key) or []

    try:
        qs = (
            SubCategory.objects
            .active()
            .select_related('category')
            .annotate(
                live_product_count=Count(
                    'products',
                    filter=Q(products__is_active=True, products__deleted_at__isnull=True),
                    distinct=True,
                )
            )
            .values(
                'pk', 'sub_category_name', 'sub_category_slug', 'is_featured',
                'category_id', 'category__category_name', 'category__category_slug',
                'live_product_count',
            )
            .order_by('category__category_name', 'display_order', 'sub_category_name')
        )
        data = [
            {
                'pk':                      r['pk'],
                'sub_category_name':       r['sub_category_name'],
                'sub_category_slug':       r['sub_category_slug'],
                'is_featured':             r['is_featured'],
                'category_id':             r['category_id'],
                'category__category_name': r['category__category_name'],
                'category__category_slug': r['category__category_slug'],
                'product_count':           r['live_product_count'],
            }
            for r in qs
        ]
        _safe_cache_set(key, data, TTL_FRAGMENT_LIST)
        return data
    finally:
        _unlock(key)


def _get_brand_category_map() -> dict[str, list]:
    key  = 'de:brand_cat_map'
    data = _safe_cache_get(key)
    if data is not None:
        return data

    got_lock = _lock(key)
    if not got_lock:
        return _safe_cache_get(key) or {}

    try:
        pairs = (
            Product.objects.active_products()
            .filter(brand__brand_slug__isnull=False, category__category_slug__isnull=False)
            .values('brand__brand_slug', 'category__category_slug')
            .distinct()
        )
        result: dict[str, list] = {}
        for row in pairs:
            result.setdefault(row['brand__brand_slug'], []).append(row['category__category_slug'])
        _safe_cache_set(key, result, TTL_FRAGMENT_LIST)
        return result
    finally:
        _unlock(key)


def _get_brand_subcategory_map() -> dict[str, list]:
    key  = 'de:brand_subcat_map'
    data = _safe_cache_get(key)
    if data is not None:
        return data

    got_lock = _lock(key)
    if not got_lock:
        return _safe_cache_get(key) or {}

    try:
        pairs = (
            Product.objects.active_products()
            .filter(
                brand__brand_slug__isnull=False,
                sub_category__sub_category_slug__isnull=False,
            )
            .values('brand__brand_slug', 'sub_category__sub_category_slug')
            .distinct()
        )
        result: dict[str, list] = {}
        for row in pairs:
            result.setdefault(row['brand__brand_slug'], []).append(
                row['sub_category__sub_category_slug']
            )
        _safe_cache_set(key, result, TTL_FRAGMENT_LIST)
        return result
    finally:
        _unlock(key)


def _get_total_product_count() -> int:
    key   = 'de:total'
    count = _safe_cache_get(key)
    if count is not None:
        return count

    got_lock = _lock(key)
    if not got_lock:
        return _safe_cache_get(key) or 0

    try:
        count = Product.objects.active_products().count()
        _safe_cache_set(key, count, TTL_TOTAL_COUNT)
        return count
    finally:
        _unlock(key)


# ═══════════════════════════════════════════════════════════════════
# ██  TWO-TIER SCORED FEED CACHE
# ═══════════════════════════════════════════════════════════════════

def _get_scored_feed(
    products_qs,
    user,
    params: FilterParams,
) -> tuple[object, int]:
    """
    Tier-2 (page slice) → Tier-1 (full scored list) → DB + FeedEngine.

    Returns (page_obj, total_count).
    page_obj.object_list contains formatted product dicts.
    """
    user_id  = user.pk if (user and user.is_authenticated) else 0
    base_key = _feed_base_key(
        user_id, params.query, params.filter_slug, params.sort_by
    )
    page_key = _feed_page_key(
        user_id, params.query, params.filter_slug, params.sort_by,
        params.page, params.min_price, params.max_price, params.in_stock,
    )

    # Tier-2 hit
    # FIX: always store/return a tuple so caller's  page_obj, _ = ...  never
    # raises 'too many values to unpack'. Old bare-page_obj entries in cache
    # are handled by the isinstance guard during the TTL rollover window.
    cached_page = _safe_cache_get(page_key)
    if cached_page is not None:
        if isinstance(cached_page, tuple):
            return cached_page
        # Legacy bare page_obj in cache — unwrap safely
        _safe_cache_delete(page_key)  # evict stale format

    # Tier-1 hit
    scored_list = _safe_cache_get(base_key)

    if scored_list is None:
        got_lock = _lock(base_key)
        if not got_lock:
            time.sleep(0.06)
            scored_list = _safe_cache_get(base_key)

        if scored_list is None and got_lock:
            try:
                raw_list      = list(products_qs.order_by(*SORT_MAP.get(params.sort_by, ['-created_at'])))
                dealer_counts = _batch_dealer_product_counts(raw_list)
                formatted     = _format_products(raw_list, params.query, dealer_counts)
                # UPGRADE-3: use FeedEngine for scoring
                engine        = FeedEngine(user)
                scored_list   = engine.rank_dicts(formatted, diversify=True)
                _safe_cache_set(base_key, scored_list, TTL_FEED_BASE)
            finally:
                _unlock(base_key)

    scored_list = scored_list or []
    total_count = len(scored_list)

    paginator = Paginator(scored_list, PRODUCTS_PER_PAGE)
    safe_page = min(params.page, paginator.num_pages) if paginator.num_pages else 1
    page_obj  = paginator.get_page(safe_page)

    _safe_cache_set(page_key, (page_obj, total_count), TTL_FEED_PAGE)
    return page_obj, total_count


# ═══════════════════════════════════════════════════════════════════
# ██  PAGINATE + FORMAT HELPER
# ═══════════════════════════════════════════════════════════════════

def _paginate_and_format(
    products_qs,
    page_number: int,
    query: str,
) -> tuple[int, object, list[dict]]:
    """Returns (total_count, page_obj, formatted_products)."""
    total_count = products_qs.count()
    paginator   = Paginator(products_qs, PRODUCTS_PER_PAGE)
    safe_page   = min(page_number, paginator.num_pages) if paginator.num_pages else 1
    page_obj    = paginator.get_page(safe_page)

    raw_list      = list(page_obj.object_list)
    dealer_counts = _batch_dealer_product_counts(raw_list)
    formatted     = _format_products(raw_list, query, dealer_counts)
    return total_count, page_obj, formatted


# ═══════════════════════════════════════════════════════════════════
# ██  PRODUCT FORMATTER  (UPGRADE-7 / UPGRADE-11)
# ═══════════════════════════════════════════════════════════════════

_DIGIT_SPLIT = re.compile(r'(\d+)')


def _format_products(
    product_list: list,
    query: str = '',
    dealer_counts: dict | None = None,
) -> list[dict]:
    """
    Convert ORM Product instances into template-ready dicts.

    UPGRADE-2:  badge resolution delegated entirely to resolve_badges_from_dict().
    UPGRADE-7:  all fields the template reads are guaranteed present.
    UPGRADE-11: additional template-compatibility fixes:
        • 'image'         → full URL via product.image_url  (not raw FileField)
        • 'brand_logo'    → full URL via _media()
        • 'seller_photo'  → full URL via _media() / profile helper
        • 'rating'        → int (star loop uses  forloop.counter <= product.rating)
    """
    if dealer_counts is None:
        dealer_counts = {}

    keywords = [w for w in query.split() if w][:10]

    def highlight(text: str) -> str:
        """XSS-safe: escape first, then wrap with <mark>."""
        safe = escape(text or '')
        if not keywords:
            return safe
        for word in keywords:
            pattern = re.compile(re.escape(escape(word)), re.IGNORECASE)
            safe    = pattern.sub(
                lambda m: f'<mark class="highlight">{m.group()}</mark>',
                safe,
            )
        return safe

    formatted = []

    for product in product_list:

        # ── Seller info ────────────────────────────────────────────
        seller_name        = 'Seller'
        seller_photo_url   = '/static/defaults/default-profile-picture.png'
        seller_verified    = False
        seller_profile_url = '#'
        seller_views       = 0
        seller_followers   = 0

        try:
            profile = product.dealer.profileinfo
            # Prefer full_name; fall back to profile_name, then username
            seller_name = (
                getattr(profile, 'full_name', None)
                or getattr(profile, 'profile_name', None)
                or getattr(product.dealer, 'email_or_phone', 'Seller')
                or 'Seller'
            )
            # UPGRADE-11: resolve photo to a full URL
            raw_photo = None
            if hasattr(profile, 'get_profile_photo_url'):
                raw_photo = profile.get_profile_photo_url()
            elif hasattr(profile, 'profile_photo') and profile.profile_photo:
                raw_photo = _media(str(profile.profile_photo))
            seller_photo_url   = raw_photo or '/static/defaults/default-profile-picture.png'
            seller_verified    = getattr(profile, 'is_verified', False)
            seller_profile_url = getattr(profile, 'profile_url', '#') or '#'
            seller_views       = getattr(profile, 'profile_views', 0) or 0
            seller_followers   = getattr(profile, 'follower_count', 0) or 0
        except Exception:
            if product.dealer:
                seller_name = getattr(product.dealer, 'email_or_phone', 'Seller') or 'Seller'

        seller_total_products = dealer_counts.get(product.dealer_id, 0)

        # ── Stock ──────────────────────────────────────────────────
        stock        = product.stock or 0
        threshold    = product.low_stock_threshold or 10
        is_in_stock  = stock > 0
        is_low_stock = 0 < stock <= threshold

        if stock == 0:
            stock_badge  = 'Out of Stock'
            stock_class  = 'out-of-stock'
            stock_status = 'Out of Stock'
        elif is_low_stock:
            stock_badge  = f'Only {stock} left'
            stock_class  = 'low-stock'
            stock_status = 'Low Stock'
        else:
            stock_badge  = None
            stock_class  = 'in-stock'
            stock_status = 'In Stock'

        # ── Pricing ────────────────────────────────────────────────
        discount_pct   = float(product.discount_percentage or 0)
        discount_badge = f'{int(discount_pct)}% OFF' if discount_pct > 0 else None
        final_price    = product.final_price or product.selling_price

        # ── Relations ─────────────────────────────────────────────
        brand    = product.brand
        category = product.category
        sub_cat  = product.sub_category

        # ── UPGRADE-11: brand_logo as full URL ─────────────────────
        brand_logo_url = None
        if brand:
            raw_logo = None
            if hasattr(brand, 'logo_url'):
                raw_logo = brand.logo_url
            elif hasattr(brand, 'brand_logo') and brand.brand_logo:
                raw_logo = _media(str(brand.brand_logo))
            brand_logo_url = raw_logo or None

        # ── UPGRADE-11: product image as full URL ──────────────────
        # The template uses {{ product.image }} directly as <img src>.
        # product.image_url is the model property that returns the full URL.
        product_image_url = None
        if hasattr(product, 'image_url'):
            product_image_url = product.image_url
        elif product.image:
            product_image_url = _media(str(product.image))
        product_image_url = product_image_url or '/static/defaults/default-product.png'

        # ── UPGRADE-11: seller username for URL tag ────────────────
        seller_username = ''
        if product.dealer:
            seller_username = getattr(product.dealer, 'email_or_phone', '') or ''

        # ── UPGRADE-11: rating cast to int for star loop ───────────
        # Template: {% if forloop.counter <= product.rating %}
        # forloop.counter is always an int; comparing int > float works in
        # Python but Django template tag comparison requires same type, so
        # store as int to be safe.
        rating_int = int(float(product.rating_average or 0))

        # ── Assembled dict ─────────────────────────────────────────
        entry = {
            # Identity
            'id':   product.pk,
            'uuid': str(product.product_id),
            'slug': product.slug,
            'sku':  product.sku,

            # Display names
            'title':                    product.product_title or '',
            'product_name':             product.product_name  or '',
            'highlighted_title':        highlight(product.product_title or ''),
            'highlighted_product_name': highlight(product.product_name  or ''),
            'short_description':        product.short_description or '',

            # Pricing
            'brand_price':         format_price(product.brand_price) if product.brand_price else None,
            'original_price':      format_price(product.selling_price),
            'final_price':         format_price(final_price),
            'discount_percentage': discount_pct,   # float — used by badge resolver
            'discount_pct':        discount_pct,   # alias — also used by badge resolver
            'discount_badge':      discount_badge,
            'on_sale':             discount_pct > 0,

            # Media
            # UPGRADE-11: 'image' is now the full URL the template needs for
            #   <img src="{{ product.image }}">
            'image':     product_image_url,
            'video_url': product.video_url,

            # Seller
            'seller_name':           seller_name,
            'seller_photo':          seller_photo_url,
            'seller_verified':       seller_verified,
            'seller_profile_url':    seller_profile_url,
            'seller_views':          format_views(seller_views),
            'seller_followers':      format_count(seller_followers),
            # UPGRADE-11: seller_username used in {% url 'customer:profile_view' username=product.seller_username %}
            'seller_username':       seller_username,
            'seller_total_products': seller_total_products,

            # Analytics
            'views':          format_views(product.view_count),
            'views_raw':      product.view_count or 0,
            # UPGRADE-11: rating as int — star loop compares forloop.counter (int) <= rating
            'rating':         rating_int,
            'rating_raw':     float(product.rating_average or 0),  # kept for badge resolver
            'review_count':   product.review_count   or 0,
            'total_sales':    product.total_sales     or 0,
            'wishlist_count': product.wishlist_count  or 0,

            # Stock — 'in_stock' key always present
            'stock':        stock,
            'stock_count':  format_count(stock),
            'stock_status': stock_status,
            'stock_badge':  stock_badge,
            'stock_class':  stock_class,
            'in_stock':     is_in_stock,
            'is_low_stock': is_low_stock,

            # Classification
            'brand':             brand.brand_name        if brand    else 'No Brand',
            'brand_slug':        brand.brand_slug        if brand    else None,
            # UPGRADE-11: brand_logo is now a full URL so <img src="{{ product.brand_logo }}"> works
            'brand_logo':        brand_logo_url,
            'brand_is_verified': getattr(brand, 'is_verified', False) if brand else False,
            'category':          category.category_name  if category else 'Uncategorized',
            'category_slug':     category.category_slug  if category else None,
            'sub_category':      sub_cat.sub_category_name if sub_cat else None,
            'sub_category_slug': sub_cat.sub_category_slug if sub_cat else None,

            # Status flags — used by badge resolver AND template directly
            'is_featured':   product.is_featured,
            'is_verified':   product.is_verified,
            'is_trending':   product.is_trending,
            'free_shipping': product.free_shipping,
            'condition':     product.get_product_condition_display(),

            # URLs
            'product_url': product.product_url,

            # Feed scoring inputs
            'created_at': product.created_at,
            'dealer_id':  product.dealer_id,

            # Formatted age
            'age_days': _format_age(
                (timezone.now() - product.created_at).total_seconds() / 86400
            ) if product.created_at else '?',
        }

        formatted.append(entry)

    # UPGRADE-2: resolve all badges in one pass via the registry
    attach_badges_to_products(formatted)   # adds 'badges' key to each dict
    return formatted


# ═══════════════════════════════════════════════════════════════════
# ██  NULL PAGE OBJECT  (UPGRADE-11)
# ═══════════════════════════════════════════════════════════════════

class _NullPage:
    """
    Returned as page_obj when the product list is empty so that the
    inline JS in the template never sees an undefined variable:

        const totalPages = {{ page_obj.paginator.num_pages }};
        let page = {{ page_obj.number }};
    """
    number = 1

    class paginator:
        num_pages = 1

    def __bool__(self):
        return False


_NULL_PAGE = _NullPage()


# ═══════════════════════════════════════════════════════════════════
# ██  MAIN VIEW
# ═══════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════
# ██  FOLLOW RELATIONSHIP RESOLVER  (UPGRADE-12 final)
# ═══════════════════════════════════════════════════════════════════

def _resolve_following_ids(user) -> list[int]:
    """
    Return the list of User PKs that `user` is currently following.

    ProfileInfo.following is a M2M → User (AUTH_USER_MODEL).
    So we query .values_list('id', flat=True) — NOT 'user_id'.
    """
    try:
        from apps.customer.models.profile_info import ProfileInfo
        current_profile = ProfileInfo.objects.using('default').get(user=user)
        return list(
            current_profile.following
            .using('default')
            .values_list('id', flat=True)   # ← was 'user_id' (wrong)
        )
    except Exception:
        logger.warning(
            'DiscoveryEngine: _resolve_following_ids failed for user=%s',
            user.pk, exc_info=True,
        )
        return []


def DiscoveryEngineView(request: HttpRequest) -> HttpResponse:
    """
    Request flow
    ────────────
    0.  Rate limit check
    1.  Parse all params via FilterParams.from_request()       (UPGRADE-4)
    2.  ETag pre-check (returns 304 if cached)
    3.  Load filter fragments  (brand / cat / subcat)
    4.  Build base queryset    (.only() + select_related, zero N+1)
    5.  FilterPipeline.run()   all panel filters + sort applied (UPGRADE-1)
    6.  Sort path:
          name_az     → natural_sort_pks() + Case/When re-fetch
          discount     → DB filter + ORDER BY
          explicit     → DB ORDER BY
          feed sorts  → FeedEngine.rank_dicts() + two-tier cache (UPGRADE-3)
    7.  Inject per-user wishlist state
    8.  Record ProfileViewLog entries for seller profiles       (UPGRADE-6)
    9.  Async view-log dispatch
    10. Build context + ETag / Cache-Control + render
    """

    # ── 0. Rate limit ─────────────────────────────────────────────
    if not _check_rate_limit(request):
        return HttpResponse(
            'Too many requests.', status=429,
            headers={'Retry-After': str(_RL_WINDOW_S)},
        )

    # ── 1. Parse params  (UPGRADE-4) ──────────────────────────────
    params = FilterParams.from_request(request)

    # ── 2. Load filter fragments ──────────────────────────────────
    brands         = _get_active_brands()
    categories     = _get_active_categories()
    sub_categories = _get_active_sub_categories()
    total_count    = _get_total_product_count()

    brand_category_map    = _get_brand_category_map()
    brand_subcategory_map = _get_brand_subcategory_map()

    # ── 3. Base queryset ──────────────────────────────────────────
    base_qs = (
        Product.objects
        .active_products()
        .only(*PRODUCT_FIELDS)
        .select_related(
            'brand',
            'category',
            'sub_category',
            'dealer__profileinfo',
        )
    )

    # ── 4. FilterPipeline  (UPGRADE-1) ────────────────────────────
    pipeline = FilterPipeline(
        brands=brands,
        categories=categories,
        sub_categories=sub_categories,
    )

    products_qs, filter_meta = pipeline.run(base_qs, params)

    if filter_meta.unknown_filter:
        messages.warning(
            request,
            f'Filter "{escape(params.filter_slug)}" not found.',
        )

    # ── 5. Sort + paginate + (optionally) rank ────────────────────
    # UPGRADE-11: page_obj starts as _NULL_PAGE so the inline JS tags
    #             {{ page_obj.number }} and {{ page_obj.paginator.num_pages }}
    #             never render as "None" or raise TemplateSyntaxError.
    page_obj           = _NULL_PAGE
    formatted_products = []

    if params.sort_by == 'name_az':
        # natural_sort_pks from filter_products.py  (UPGRADE-8)
        all_sorted_pks = natural_sort_pks(products_qs)

        paginator = Paginator(all_sorted_pks, PRODUCTS_PER_PAGE)
        safe_page = min(params.page, paginator.num_pages) if paginator.num_pages else 1
        page_obj  = paginator.get_page(safe_page)
        page_pks  = list(page_obj)

        if page_pks:
            ordering_case = Case(
                *[When(pk=pk, then=Value(idx)) for idx, pk in enumerate(page_pks)],
                output_field=IntegerField(),
            )
            page_qs = (
                products_qs
                .filter(pk__in=page_pks)
                .annotate(_sort_order=ordering_case)
                .order_by('_sort_order')
            )
            raw_list           = list(page_qs)
            dealer_counts      = _batch_dealer_product_counts(raw_list)
            formatted_products = _format_products(raw_list, params.query, dealer_counts)

    elif params.sort_by == 'discount':
        _, page_obj, formatted_products = _paginate_and_format(
            products_qs, params.page, params.query
        )

    elif params.sort_by in EXPLICIT_SORT_BYPASSES:
        _, page_obj, formatted_products = _paginate_and_format(
            products_qs, params.page, params.query
        )

    else:
        # Feed sorts: two-tier cache + FeedEngine.rank_dicts()  (UPGRADE-3)
        page_obj, _ = _get_scored_feed(
            products_qs=products_qs,
            user=request.user,
            params=params,
        )
        formatted_products = list(page_obj)

    # ── 6. Per-user wishlist state ─────────────────────────────────
    wishlisted_ids = _get_wishlisted_ids(request.user)

    # ── 7. ETag check ─────────────────────────────────────────────
    user_pk  = request.user.pk if request.user.is_authenticated else None
    etag_val = _build_etag(formatted_products, user_pk)
    if request.META.get('HTTP_IF_NONE_MATCH') == f'"{etag_val}"':
        return HttpResponse(status=304)

    # ── 8. ProfileViewLog  (UPGRADE-6) ────────────────────────────
    _record_profile_views(formatted_products, request.user)

    # ── 9. Async view-log dispatch ────────────────────────────────
    try:
        product_db_ids = [p['id'] for p in formatted_products]
        _dispatch_view_logs(product_db_ids, user_pk)
    except Exception:
        pass

    # ── 10. Suggested dealers ──────────────────────────────────────
    # UPGRADE-12 (revised): resolve following IDs by probing the four most
    # common follow-relationship shapes in order.  The first one that
    # returns a non-empty list (or an empty list without exception) wins.
    # Every query uses .using('default') to force the primary DB so a
    # recently-written follow row is never missed via a read replica.
    already_following: list[int] = []
    if request.user.is_authenticated:
        already_following = _resolve_following_ids(request.user)

    try:
        suggested_dealers = list(
            User.objects
            .filter(role='dealer', is_active=True, deleted_at__isnull=True)
            .exclude(id__in=already_following)
            .select_related('profileinfo')
            .annotate(
                product_count=Count(
                    'products',
                    filter=Q(products__is_active=True),
                )
            )
            .order_by('-product_count')[:6]
        )
    except Exception:
        suggested_dealers = []

    # UPGRADE-11: patch each suggested dealer so the sidebar template tag
    #   {{ dealer.profileinfo.profile_name }} never raises AttributeError.
    #   The model may only have `full_name`; we expose both names safely.
    for dealer in suggested_dealers:
        try:
            pi = dealer.profileinfo
            if not getattr(pi, 'profile_name', None):
                pi.profile_name = (
                    getattr(pi, 'full_name', None)
                    or getattr(dealer, 'email_or_phone', '')
                    or ''
                )
        except Exception:
            pass

    # ── 11. Context ───────────────────────────────────────────────
    context = {
        # Feed
        'products':           formatted_products,
        'page_obj':           page_obj,
        'query':              params.query,
        'total_count':        total_count,

        # Filters / sort  (UPGRADE-4 / UPGRADE-5)
        'current_filter':       params.filter_slug,
        'active_filter_type':   filter_meta.active_filter_type,
        'active_tab':           filter_meta.active_tab,
        'applied_filters':      filter_meta.applied_filters,
        'sort_by':              params.sort_by,
        'sort_options':         build_sort_options(params.sort_by),
        'tab_options':          build_tab_options(filter_meta.active_tab),
        'in_stock':             params.in_stock,
        'min_price':            params.min_price,
        'max_price':            params.max_price,

        # Panel data
        'all_brands':         brands,
        'all_categories':     categories,
        'all_sub_categories': sub_categories,

        # JS maps
        'brand_category_map':    brand_category_map,
        'brand_subcategory_map': brand_subcategory_map,

        # Per-user state
        'wishlisted_ids':    wishlisted_ids,
        'already_following': already_following,
        'suggested_dealers': suggested_dealers,

        # UPGRADE-11: getCookie JS helper — required by wishlist/follow AJAX.
        # Rendered once via {{ get_cookie_js|safe }} anywhere before the
        # first AJAX call.  We also inject it unconditionally into the
        # response HTML via a middleware-free approach: include it in context
        # and let the base template render it.
        'get_cookie_js': _GET_COOKIE_JS,
    }

    # ── 12. Render + headers ──────────────────────────────────────
    response = render(request, 'ponno/discovery_engine.html', context)
    _set_cache_headers(response, etag_val, request.user)
    return response


# ═══════════════════════════════════════════════════════════════════
# ██  CACHE INVALIDATION
# ═══════════════════════════════════════════════════════════════════

def invalidate_user_feed(user_id: int) -> None:
    invalidate_user_affinity(user_id)
    invalidate_wishlist_cache(user_id)
    for slug in ('all', ''):
        for sort in ('newest', 'popular', 'trending'):
            _safe_cache_delete(_feed_base_key(user_id, '', slug, sort))
            _safe_cache_delete(_feed_page_key(user_id, '', slug, sort, 1, None, None, False))

def invalidate_user_feed(user_id: int) -> None:
    """Call when a user buys, wishlists, views, or follows."""
    invalidate_user_affinity(user_id)
    invalidate_wishlist_cache(user_id)
    for slug in ('all', ''):
        for sort in ('newest', 'popular'):
            _safe_cache_delete(_feed_base_key(user_id, '', slug, sort))


def invalidate_fragment_caches() -> None:
    """Call from a post_save signal on Brand / Category / Product."""
    fragment_keys = [
        'de:brands', 'de:cats', 'de:subcats', 'de:total',
        'de:brand_cat_map', 'de:brand_subcat_map',
    ]
    fb_slugs = list(TAB_FILTER_SLUGS) + ['all', '', 'brands', 'categories', 'sub_categories']
    fb_keys  = [f'de:fb:{slug}' for slug in fb_slugs]
    try:
        cache.delete_many(fragment_keys + fb_keys)
    except Exception as exc:
        logger.warning('invalidate_fragment_caches failed: %s', exc)


# ═══════════════════════════════════════════════════════════════════
# ██  FORMATTING HELPERS
# ═══════════════════════════════════════════════════════════════════

def format_count(count) -> str:
    try:
        n = int(count)
        if n >= 1_000_000: return f'{n / 1_000_000:.1f}M'.replace('.0M', 'M')
        if n >= 1_000:     return f'{n / 1_000:.1f}k'.replace('.0k', 'k')
        return str(n)
    except (ValueError, TypeError):
        return '0'


def format_views(views) -> str:
    try:
        n = int(views)
        if n >= 1_000_000: return f'{n / 1_000_000:.1f}M'.replace('.0M', 'M')
        if n >= 1_000:     return f'{n / 1_000:.1f}K'.replace('.0K', 'K')
        return str(n)
    except (ValueError, TypeError):
        return '0'


def format_price(price) -> str:
    try:
        if price is None:
            return '0 Tk'
        d = Decimal(str(price))

        def bd_format(n: int) -> str:
            s = str(n)
            if len(s) <= 3:
                return s
            result = s[-3:]
            s = s[:-3]
            while s:
                result = s[-2:] + ',' + result
                s = s[:-2]
            return result

        if d == d.to_integral_value():
            return f'{bd_format(int(d))} Tk'

        integer_part = int(d)
        decimal_part = f'{d:.2f}'.split('.')[1]
        return f'{bd_format(integer_part)}.{decimal_part} Tk'

    except (ValueError, TypeError):
        return '0 Tk'


def _format_age(days: float) -> str:
    total_seconds = round(days * 86400)
    if total_seconds < 5:    return 'Just now'
    if total_seconds < 60:   return f'{total_seconds}s ago'
    minutes = total_seconds // 60
    if minutes < 60:         return f'{minutes}m ago'
    hours = minutes // 60
    if hours < 24:           return f'{hours}h ago'
    d = hours // 24
    if d == 1:               return 'Yesterday'
    if d < 7:                return f'{d}d ago'
    weeks = d // 7
    if weeks < 5:            return f'{weeks}w ago'
    months = d // 30
    if months < 12:          return f'{months}mo ago'
    years  = d // 365
    rem    = (d % 365) // 30
    return f'{years}y {rem}mo ago' if rem else f'{years}y ago'


# ═══════════════════════════════════════════════════════════════════
# ██  ENGINE VIEW  (authenticated stub)
# ═══════════════════════════════════════════════════════════════════

@login_required
def EngineView(request: HttpRequest) -> HttpResponse:
    return render(request, 'business/engine.html', {})