"""
Discovery Engine View — upgraded to use apps.ponno.feed_algorithm
=================================================================

CHANGES vs previous version
────────────────────────────
1. ALGORITHM    All scoring, affinity, diversity, and tab-filter logic
                delegated to feed_algorithm.py — zero duplication.

2. CACHE        Two-tier feed cache retained (Tier1 base list, Tier2 page).
                Stampede guard (cache.add lock) wraps only the DB+score path.

3. IMPORTS      math / defaultdict / _load_user_affinity / _rank_products
                all removed from this file — live in feed_algorithm now.

4. TAB FILTERS  get_tab_filter_map() called fresh per request so the
                'new' filter timestamp is always live.

5. INVALIDATION invalidate_user_affinity() from feed_algorithm replaces
                the local cache.delete('aff:…') call.

FIXES (vs previous version)
────────────────────────────
FIX-1  Removed spurious `from requests import request` import.
FIX-2  Stampede guard: _unlock() is now only called when _lock() succeeded,
        preventing an unlock of a lock we never held.
FIX-4  N+1 query in _format_products for seller_total_products eliminated:
        dealer product counts are batch-loaded once via
        _batch_dealer_product_counts() and passed into _format_products.
FIX-6  wishlisted_ids compared correctly: built as a set of strings
        (str(uuid)) so the template `product.uuid in wishlisted_ids` check
        always works.
FIX-7  Template key corrected: _format_products now emits 'in_stock' (not
        'is_in_stock') so the {% if product.in_stock %} badge renders.
FIX-11 invalidate_fragment_caches() now also clears all 'de:fb:*' filter-
        button cache keys so stale counts are never served after a Brand /
        Category / Product post_save signal.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCALING LAYERS (unchanged)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Layer 0  Nginx micro-cache  (zero Python/DB cost for anonymous hits)
Layer 1  Two-tier feed cache: base scored list + per-page slice
Layer 2  Fragment cache: brands / cats / subcats / filter buttons
Layer 3  DB query minimisation (.only(), tight select_related)
Layer 4  Python work reduction (pre-computed dicts, no per-item ORM)
Layer 5  Stampede protection   (cache.add() lock — one rebuilder only)
"""

from __future__ import annotations

from datetime import timedelta
import re
import hashlib
import logging
import time

from django.core.cache import cache
from django.core.paginator import Paginator, InvalidPage
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import Http404
from django.shortcuts import render
from django.utils import timezone
from django.utils.html import escape
from django.db.models import Q, Value, Case, When, IntegerField, Count

# FIX-1: removed `from requests import request` — was unused and shadowed
#         Django's request object name.

from apps.ponno.models.brand import Brand
from apps.ponno.models.category import Category
from apps.ponno.models.sub_category import SubCategory
from apps.ponno.models.product import Product

from apps.ponno.feed_algorithm import (
    rank_and_diversify,
    get_tab_filter_map,
    TAB_FILTER_NAMES,
    TAB_FILTER_SLUGS,
    invalidate_user_affinity,
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────
# TUNEABLE CONSTANTS — CACHE TTLs
# ─────────────────────────────────────────────────────────────────────

PRODUCTS_PER_PAGE  = 20
TTL_FEED_PAGE      = 60      # Tier-2: per-page slice
TTL_FEED_BASE      = 120     # Tier-1: full scored list
TTL_FRAGMENT_LIST  = 180     # brand / cat / subcat fragments
TTL_TOTAL_COUNT    = 120     # total product count
TTL_FILTER_BUTTONS = 120     # filter button list
TTL_LOCK           = 10      # stampede lock TTL


# ─────────────────────────────────────────────────────────────────────
# SORT CONFIG
# ─────────────────────────────────────────────────────────────────────

EXPLICIT_SORT_BYPASSES = frozenset({
    'price_low', 'price_high', 'rating', 'discount', 'name_az',
})

VALID_SORTS = frozenset({
    'newest', 'popular', 'price_low',
    'price_high', 'rating', 'discount', 'name_az',
})

SORT_MAP: dict[str, list[str]] = {
    'newest':     ['-created_at'],
    'popular':    ['-view_count', '-total_sales'],
    'price_low':  ['selling_price'],
    'price_high': ['-selling_price'],
    'rating':     ['-rating_average', '-review_count'],
    'discount':   ['-discount_percentage'],
}

PRODUCT_FIELDS = [
    'pk', 'product_id', 'slug', 'sku',
    'product_title', 'product_name', 'short_description',
    'brand_price', 'selling_price', 'final_price', 'discount_percentage',
    'image', 'video_url', 'free_shipping',
    'view_count', 'rating_average', 'review_count', 'total_sales',
    'wishlist_count',
    'stock', 'stock_status', 'low_stock_threshold',
    'is_featured', 'is_verified', 'is_trending',
    'product_condition',
    'brand_id', 'category_id', 'sub_category_id', 'dealer_id',
    'created_at',
]


# ═════════════════════════════════════════════════════════════════════
# ██  CACHE KEY HELPERS
# ═════════════════════════════════════════════════════════════════════

def _ck(*parts) -> str:
    raw = ':'.join(str(p) for p in parts)
    return 'de:' + hashlib.blake2b(raw.encode(), digest_size=10).hexdigest()

def _feed_base_key(user_id, query, filter_slug, sort_by) -> str:
    return _ck('base', user_id, query, filter_slug, sort_by)

def _feed_page_key(user_id, query, filter_slug, sort_by, page, min_p, max_p, in_stock) -> str:
    return _ck('page', user_id, query, filter_slug, sort_by, page, min_p, max_p, in_stock)


# ═════════════════════════════════════════════════════════════════════
# ██  STAMPEDE GUARD
# ═════════════════════════════════════════════════════════════════════

def _lock(key: str) -> bool:
    return cache.add(f'lock:{key}', 1, TTL_LOCK)

def _unlock(key: str) -> None:
    cache.delete(f'lock:{key}')


# ─────────────────────────────────────────────────────────────────────
# NATURAL SORT
# ─────────────────────────────────────────────────────────────────────

_DIGIT_SPLIT = re.compile(r'(\d+)')

def _natural_sort_key(name: str) -> list:
    if not name:
        return [(1, '')]
    dash_idx = name.find('-')
    segment  = name[dash_idx + 1:] if dash_idx != -1 else name
    parts    = _DIGIT_SPLIT.split(segment)
    return [
        (0, int(p)) if p.isdigit() else (1, p.upper())
        for p in parts if p
    ]


# ═════════════════════════════════════════════════════════════════════
# ██  BATCH DEALER PRODUCT COUNTS  (FIX-4: eliminates N+1 query)
# ═════════════════════════════════════════════════════════════════════

def _batch_dealer_product_counts(product_list: list) -> dict[int, int]:
    """
    Given a list of ORM Product instances, return a dict of
    {dealer_id: active_product_count} fetched in a single query.

    Previously _format_products() called
        product.dealer.products.filter(is_active=True).count()
    inside a loop — one extra DB round-trip per product card.
    This helper does it once for all dealer IDs in the batch.
    """
    dealer_ids = {p.dealer_id for p in product_list if p.dealer_id}
    if not dealer_ids:
        return {}
    rows = (
        Product.objects
        .filter(dealer_id__in=dealer_ids, is_active=True)
        .values('dealer_id')
        .annotate(cnt=Count('pk'))
    )
    return {row['dealer_id']: row['cnt'] for row in rows}


# ═════════════════════════════════════════════════════════════════════
# ██  TWO-TIER SCORED FEED CACHE
# ═════════════════════════════════════════════════════════════════════

def _get_scored_feed(
    products_qs,
    user,
    query: str,
    filter_slug: str,
    sort_by: str,
    page_number: int,
    min_price: str,
    max_price: str,
    in_stock: bool,
):
    """
    Tier 2 (page slice) → Tier 1 (scored list) → DB + rank_and_diversify

    Page 2, 3, 4 … reuse the Tier-1 scored list with zero DB cost.
    Scoring delegated to feed_algorithm.rank_and_diversify().

    FIX-2: _unlock() is only called when we actually acquired the lock,
    preventing spurious cache.delete() calls on keys we never locked.
    """
    user_id  = user.pk if (user and user.is_authenticated) else 0
    base_key = _feed_base_key(user_id, query, filter_slug, sort_by)
    page_key = _feed_page_key(
        user_id, query, filter_slug, sort_by,
        page_number, min_price, max_price, in_stock,
    )

    # ── Tier-2 hit: entire page from cache ───────────────────────
    page_obj = cache.get(page_key)
    if page_obj is not None:
        return page_obj, None

    # ── Tier-1 hit: re-use scored list, paginate in Python ───────
    scored_list = cache.get(base_key)

    if scored_list is None:
        # FIX-2: only attempt to build if we won the lock.
        #        If we lost the lock, wait briefly and re-check the cache.
        #        Never call _unlock() unless _lock() returned True.
        got_lock = _lock(base_key)
        if not got_lock:
            time.sleep(0.05)
            scored_list = cache.get(base_key)

        if scored_list is None and got_lock:
            try:
                raw_list  = list(
                    products_qs.order_by(*SORT_MAP.get(sort_by, ['-created_at']))
                )
                # FIX-4: batch-load dealer product counts before formatting
                dealer_counts = _batch_dealer_product_counts(raw_list)
                formatted     = _format_products(raw_list, query, dealer_counts)
                scored_list   = rank_and_diversify(
                    formatted, user=user, apply_diversity=True
                )
                cache.set(base_key, scored_list, TTL_FEED_BASE)
            finally:
                # FIX-2: only unlock what we locked
                _unlock(base_key)

    total_count = len(scored_list) if scored_list else 0
    paginator   = Paginator(scored_list or [], PRODUCTS_PER_PAGE)
    page_obj    = paginator.get_page(page_number)

    cache.set(page_key, page_obj, TTL_FEED_PAGE)
    return page_obj, total_count


# ═════════════════════════════════════════════════════════════════════
# ██  MAIN VIEW
# ═════════════════════════════════════════════════════════════════════

def HomeView(request):
    """
    Request flow
    ────────────
    1. Parse & validate URL params           (zero cost)
    2. Load filter fragments                 (fragment cache)
    3. Build base queryset                   (.only() / select_related)
    4. Apply filter                          (tab → brand → cat → subcat)
    5. Apply search                          (icontains per word)
    6. Apply price / stock filters
    7. Sort + paginate:
         name_az  → Python natural sort
         discount → explicit DB sort
         other explicit sorts → DB sort, no re-ranking
         newest / popular → two-tier cache + rank_and_diversify
    8. Build context & render
    """

    # ── 1. Parse & sanitize ─────────────────────────────────────────
    query       = request.GET.get('q',         '').strip()[:200]
    filter_slug = request.GET.get('filter', 'all').strip()[:80]
    sort_by     = request.GET.get('sort',      'newest').strip()
    min_price   = request.GET.get('min_price', '').strip()
    max_price   = request.GET.get('max_price', '').strip()
    in_stock    = request.GET.get('in_stock',  'false') == 'true'
    page_number = request.GET.get('page',      '1').strip()

    if sort_by not in VALID_SORTS:
        sort_by = 'newest'

    try:
        page_number = max(1, int(page_number))
    except (ValueError, TypeError):
        page_number = 1

    # ── 2. Load filter fragments ─────────────────────────────────────
    brands         = _get_active_brands()
    categories     = _get_active_categories()
    sub_categories = _get_active_sub_categories()

    brand_category_map    = _get_brand_category_map()
    brand_subcategory_map = _get_brand_subcategory_map()

    brand_map        = {b['brand_slug']: b        for b in brands}
    category_map     = {c['category_slug']: c     for c in categories}
    sub_category_map = {s['sub_category_slug']: s for s in sub_categories}

    # ── 3. Base queryset ─────────────────────────────────────────────
    products = (
        Product.objects
        .active_products()
        .only(*PRODUCT_FIELDS)
        .select_related(
            'brand',
            'category',
            'sub_category',
            'dealer',
            'dealer__profileinfo',
        )
    )

    # ── 4. Filter ────────────────────────────────────────────────────
    active_filter_name = 'All Products'
    active_filter_type = 'all'

    # Fresh map per request so 'new' timestamp is always current
    tab_filter_map = get_tab_filter_map()

    if filter_slug in TAB_FILTER_SLUGS:
        products           = products.filter(tab_filter_map[filter_slug])
        active_filter_name = TAB_FILTER_NAMES[filter_slug]
        active_filter_type = filter_slug

    elif filter_slug and filter_slug not in ('all', '', 'brands', 'categories', 'sub_categories'):
        if filter_slug in brand_map:
            products           = products.filter(brand__brand_slug=filter_slug)
            active_filter_name = brand_map[filter_slug]['brand_name']
            active_filter_type = 'brand'
        elif filter_slug in category_map:
            cat_info = category_map[filter_slug]
            products = products.filter(
                Q(category__category_slug=filter_slug) |
                Q(category__path__startswith=cat_info['path'] + '/')
            )
            active_filter_name = cat_info['category_name']
            active_filter_type = 'category'
        elif filter_slug in sub_category_map:
            products           = products.filter(sub_category__sub_category_slug=filter_slug)
            active_filter_name = sub_category_map[filter_slug]['sub_category_name']
            active_filter_type = 'sub_category'
        else:
            messages.warning(request, f'Filter "{escape(filter_slug)}" not found.')

    # ── 5. Search ────────────────────────────────────────────────────
    search_applied = False
    if query:
        search_applied = True
        q_obj = Q()
        for word in query.split()[:10]:
            q_obj |= (
                Q(product_title__icontains=word)           |
                Q(product_name__icontains=word)            |
                Q(description__icontains=word)             |
                Q(short_description__icontains=word)       |
                Q(brand__brand_name__icontains=word)       |
                Q(category__category_name__icontains=word) |
                Q(sku__icontains=word)
            )
        products = products.filter(q_obj).distinct()

    # ── 6. Price / stock filters ─────────────────────────────────────
    try:
        if min_price:
            products = products.filter(selling_price__gte=float(min_price))
    except ValueError:
        pass
    try:
        if max_price:
            products = products.filter(selling_price__lte=float(max_price))
    except ValueError:
        pass

    if in_stock:
        products = products.filter(stock__gt=0)

    # ── 7. Sort + paginate + (optionally) rank ───────────────────────
    formatted_products = []
    total_filtered     = 0

    if sort_by == 'name_az':
        name_rows      = list(products.values_list('pk', 'product_name'))
        sorted_rows    = sorted(name_rows, key=lambda r: _natural_sort_key(r[1] or ''))
        all_sorted_pks = [r[0] for r in sorted_rows]
        total_filtered = len(all_sorted_pks)

        start    = (page_number - 1) * PRODUCTS_PER_PAGE
        end      = start + PRODUCTS_PER_PAGE
        page_pks = all_sorted_pks[start:end]

        if page_pks:
            ordering_case = Case(
                *[When(pk=pk, then=Value(idx)) for idx, pk in enumerate(page_pks)],
                output_field=IntegerField(),
            )
            page_qs = (
                products
                .filter(pk__in=page_pks)
                .annotate(_sort_order=ordering_case)
                .order_by('_sort_order')
            )
            raw_list      = list(page_qs)
            dealer_counts = _batch_dealer_product_counts(raw_list)
            formatted_products = _format_products(raw_list, query, dealer_counts)

        paginator = Paginator(all_sorted_pks, PRODUCTS_PER_PAGE)
        page_obj  = paginator.get_page(page_number)

    elif sort_by == 'discount':
        products = products.filter(discount_percentage__gt=0).order_by(*SORT_MAP['discount'])
        total_filtered, page_obj, formatted_products = _paginate_and_format(
            products, page_number, query
        )

    elif sort_by in EXPLICIT_SORT_BYPASSES:
        products = products.order_by(*SORT_MAP.get(sort_by, ['-created_at']))
        total_filtered, page_obj, formatted_products = _paginate_and_format(
            products, page_number, query
        )

    else:
        # Feed sorts (newest / popular) — two-tier cache + rank_and_diversify
        page_obj, total_filtered = _get_scored_feed(
            products_qs=products,
            user=request.user,
            query=query,
            filter_slug=filter_slug,
            sort_by=sort_by,
            page_number=page_number,
            min_price=min_price,
            max_price=max_price,
            in_stock=in_stock,
        )
        formatted_products = list(page_obj)
        if total_filtered is None:
            total_filtered = page_obj.paginator.count

    # ── 8. Supporting data ───────────────────────────────────────────
    total_all_products = _get_total_product_count()
    filter_buttons     = _build_filter_buttons(
        filter_slug, active_filter_type,
        brands, categories, sub_categories,
        total_all_products,
    )

    sub_categories_by_category: dict[str, list] = {}
    for sub in sub_categories:
        sub_categories_by_category.setdefault(
            sub['category__category_slug'], []
        ).append(sub)

    sort_options = [
        {'value': 'newest',     'label': 'Newest First',       'active': sort_by == 'newest'},
        {'value': 'popular',    'label': 'Most Popular',        'active': sort_by == 'popular'},
        {'value': 'price_low',  'label': 'Price: Low to High',  'active': sort_by == 'price_low'},
        {'value': 'price_high', 'label': 'Price: High to Low',  'active': sort_by == 'price_high'},
        {'value': 'rating',     'label': 'Highest Rated',       'active': sort_by == 'rating'},
        {'value': 'discount',   'label': 'Best Discount',       'active': sort_by == 'discount'},
        {'value': 'name_az',    'label': 'Name: A → Z',         'active': sort_by == 'name_az'},
    ]

    # ── Wishlist IDs ─────────────────────────────────────────────────
    # FIX-6: store as set of strings (str(uuid)) so that
    #        `product.uuid in wishlisted_ids` in the template always works
    #        regardless of how the DB driver returns the UUID type.
    try:
        wishlisted_ids = set(
            str(uid)
            for uid in
            request.user.wishlist_items
            .values_list('product__product_id', flat=True)
        ) if request.user.is_authenticated else set()
    except Exception:
        wishlisted_ids = set()

    # ── Already following ────────────────────────────────────────────
    try:
        already_following = list(
            request.user.profileinfo.following.values_list('id', flat=True)
        ) if request.user.is_authenticated else []
    except Exception:
        already_following = []

    # ── Suggested dealers ────────────────────────────────────────────
    try:
        from django.contrib.auth import get_user_model as _get_user_model
        _User = _get_user_model()
        suggested_dealers = list(
            _User.objects
            .filter(role='dealer', is_active=True, deleted_at__isnull=True)
            .exclude(id__in=already_following)
            .select_related('profileinfo')
            .annotate(product_count=Count('products', filter=Q(products__is_active=True)))
            .order_by('-product_count')[:6]
        )
    except Exception:
        suggested_dealers = []

    context = {
        'products':           formatted_products,
        'page_obj':           page_obj,
        'total_count':        total_filtered,
        'total_products':     total_all_products,
        'query':              query,
        'search_applied':     search_applied,
        'filter_buttons':     filter_buttons,
        'current_filter':     filter_slug,
        'active_filter_name': active_filter_name,
        'active_filter_type': active_filter_type,
        'sort_by':            sort_by,
        'sort_options':       sort_options,
        'min_price':          min_price,
        'max_price':          max_price,
        'in_stock_only':      in_stock,

        'all_brands':         brands,
        'brands_count':       len(brands),

        'all_categories':     categories,
        'categories_count':   len(categories),

        'all_sub_categories':         sub_categories,
        'sub_categories_count':       len(sub_categories),
        'sub_categories_by_category': sub_categories_by_category,

        'show_brands_view':         filter_slug == 'brands',
        'show_categories_view':     filter_slug == 'categories',
        'show_sub_categories_view': filter_slug == 'sub_categories',

        'brand_category_map':    brand_category_map,
        'brand_subcategory_map': brand_subcategory_map,

        'wishlisted_ids':    wishlisted_ids,
        'already_following': already_following,
        'suggested_dealers': suggested_dealers,
    }

    return render(request, 'ponno/discovery_engine.html', context)


# ═════════════════════════════════════════════════════════════════════
# ██  HELPERS — PAGINATE, FRAGMENTS, FILTER BUTTONS, FORMATTERS
# ═════════════════════════════════════════════════════════════════════

def _paginate_and_format(products, page_number, query):
    total_filtered = products.count()
    paginator      = Paginator(products, PRODUCTS_PER_PAGE)
    try:
        page_obj = paginator.get_page(page_number)
    except InvalidPage:
        raise Http404
    raw_list      = list(page_obj)
    dealer_counts = _batch_dealer_product_counts(raw_list)   # FIX-4
    formatted     = _format_products(raw_list, query, dealer_counts)
    return total_filtered, page_obj, formatted


# ─────────────────────────────────────────────────────────────────────
# Fragment cache helpers
# ─────────────────────────────────────────────────────────────────────

def _get_active_brands():
    key  = 'de:brands'
    data = cache.get(key)
    if data is not None:
        return data
    if not _lock(key):
        return cache.get(key) or []
    try:
        from django.conf import settings
        media_url = getattr(settings, 'MEDIA_URL', '/media/')
        qs = (
            Brand.objects
            .active_brands()
            .annotate(
                live_product_count=Count(
                    'products',
                    filter=Q(products__is_active=True, products__deleted_at__isnull=True),
                    distinct=True,
                ),
                live_category_count=Count(
                    'products__category',
                    filter=Q(products__is_active=True, products__deleted_at__isnull=True),
                    distinct=True,
                ),
            )
            .values('pk', 'brand_name', 'brand_slug', 'brand_logo',
                    'is_featured', 'live_product_count', 'live_category_count')
            .order_by('-live_product_count')
        )
        data = []
        for row in qs:
            lp = row['brand_logo']
            data.append({
                'pk':             row['pk'],
                'brand_name':     row['brand_name'],
                'brand_slug':     row['brand_slug'],
                'brand_logo':     lp,
                'is_featured':    row['is_featured'],
                'product_count':  row['live_product_count'],
                'category_count': row['live_category_count'],
                'brand_logo_url': (media_url + lp) if lp else None,
            })
        cache.set(key, data, TTL_FRAGMENT_LIST)
        return data
    finally:
        _unlock(key)


def _get_active_categories():
    key  = 'de:cats'
    data = cache.get(key)
    if data is not None:
        return data
    if not _lock(key):
        return cache.get(key) or []
    try:
        qs = (
            Category.objects
            .active_categories()
            .annotate(
                live_product_count=Count(
                    'products',
                    filter=Q(products__is_active=True, products__deleted_at__isnull=True),
                    distinct=True,
                )
            )
            .values('pk', 'category_name', 'category_slug', 'is_featured',
                    'path', 'level', 'live_product_count')
            .order_by('-live_product_count')
        )
        data = [
            {
                'pk':            r['pk'],
                'category_name': r['category_name'],
                'category_slug': r['category_slug'],
                'is_featured':   r['is_featured'],
                'path':          r['path'],
                'level':         r['level'],
                'product_count': r['live_product_count'],
            }
            for r in qs
        ]
        cache.set(key, data, TTL_FRAGMENT_LIST)
        return data
    finally:
        _unlock(key)


def _get_active_sub_categories():
    key  = 'de:subcats'
    data = cache.get(key)
    if data is not None:
        return data
    if not _lock(key):
        return cache.get(key) or []
    try:
        qs = (
            SubCategory.objects
            .active()
            .select_related('category')
            .annotate(
                live_product_count=Count(
                    'products',
                    filter=Q(products__is_active=True, products__deleted_at__isnull=True),
                    distinct=True,
                )
            )
            .values('pk', 'sub_category_name', 'sub_category_slug', 'is_featured',
                    'category_id', 'category__category_name', 'category__category_slug',
                    'live_product_count')
            .order_by('category__category_name', 'display_order', 'sub_category_name')
        )
        data = [
            {
                'pk':                      r['pk'],
                'sub_category_name':       r['sub_category_name'],
                'sub_category_slug':       r['sub_category_slug'],
                'is_featured':             r['is_featured'],
                'category_id':             r['category_id'],
                'category__category_name': r['category__category_name'],
                'category__category_slug': r['category__category_slug'],
                'product_count':           r['live_product_count'],
            }
            for r in qs
        ]
        cache.set(key, data, TTL_FRAGMENT_LIST)
        return data
    finally:
        _unlock(key)


def _get_total_product_count():
    key   = 'de:total'
    count = cache.get(key)
    if count is not None:
        return count
    if not _lock(key):
        return cache.get(key) or 0
    try:
        count = Product.objects.active_products().count()
        cache.set(key, count, TTL_TOTAL_COUNT)
        return count
    finally:
        _unlock(key)


def _get_brand_category_map():
    key  = 'de:brand_cat_map'
    data = cache.get(key)
    if data is not None:
        return data
    if not _lock(key):
        return cache.get(key) or {}
    try:
        pairs = (
            Product.objects.active_products()
            .filter(brand__brand_slug__isnull=False, category__category_slug__isnull=False)
            .values('brand__brand_slug', 'category__category_slug')
            .distinct()
        )
        result: dict[str, list] = {}
        for row in pairs:
            result.setdefault(row['brand__brand_slug'], []).append(row['category__category_slug'])
        cache.set(key, result, TTL_FRAGMENT_LIST)
        return result
    finally:
        _unlock(key)


def _get_brand_subcategory_map():
    key  = 'de:brand_subcat_map'
    data = cache.get(key)
    if data is not None:
        return data
    if not _lock(key):
        return cache.get(key) or {}
    try:
        pairs = (
            Product.objects.active_products()
            .filter(brand__brand_slug__isnull=False,
                    sub_category__sub_category_slug__isnull=False)
            .values('brand__brand_slug', 'sub_category__sub_category_slug')
            .distinct()
        )
        result: dict[str, list] = {}
        for row in pairs:
            result.setdefault(row['brand__brand_slug'], []).append(
                row['sub_category__sub_category_slug']
            )
        cache.set(key, result, TTL_FRAGMENT_LIST)
        return result
    finally:
        _unlock(key)


# ─────────────────────────────────────────────────────────────────────
# Cache invalidation helpers
# ─────────────────────────────────────────────────────────────────────

def invalidate_user_feed(user_id: int) -> None:
    """
    Call when a user buys, wishlists, views, or follows.
    Clears both the affinity cache (via feed_algorithm) and the
    base feed keys for the most common no-filter variants.
    """
    invalidate_user_affinity(user_id)
    cache.delete(_feed_base_key(user_id, '', 'all',  'newest'))
    cache.delete(_feed_base_key(user_id, '', 'all',  'popular'))
    cache.delete(_feed_base_key(user_id, '', '',     'newest'))
    cache.delete(_feed_base_key(user_id, '', '',     'popular'))


def invalidate_fragment_caches() -> None:
    """
    Call from a post_save signal on Brand / Category / Product.

    FIX-11: also clears all filter-button cache keys so stale product
    counts are never served after the underlying data changes.
    Filter-button keys are namespaced under 'de:fb:' — we use
    cache.delete_many() with known slugs plus the special-case keys.
    Because Django's cache backend doesn't support wildcard deletes,
    we delete all possible TAB_FILTER_SLUGS keys plus the common
    'all' / '' / 'brands' / 'categories' / 'sub_categories' keys.
    """
    fragment_keys = [
        'de:brands', 'de:cats', 'de:subcats', 'de:total',
        'de:brand_cat_map', 'de:brand_subcat_map',
    ]

    # All filter-button cache keys we know can exist
    fb_slugs = list(TAB_FILTER_SLUGS) + [
        'all', '', 'brands', 'categories', 'sub_categories',
    ]
    fb_keys = [f'de:fb:{slug}' for slug in fb_slugs]

    cache.delete_many(fragment_keys + fb_keys)


# ─────────────────────────────────────────────────────────────────────
# Filter button builder
# ─────────────────────────────────────────────────────────────────────

def _build_filter_buttons(filter_slug, active_filter_type,
                          brands, categories, sub_categories, total):
    cache_key = f'de:fb:{filter_slug}'
    cached    = cache.get(cache_key)
    if cached is not None:
        return cached

    buttons = [{'name': f'All ({format_count(total)})', 'slug': 'all',
                'active': filter_slug in ('all', '', None), 'type': 'all', 'count': total}]

    def _brand_btn(b, active=False):
        return {'name': f"{b['brand_name']} ({format_count(b['product_count'])})",
                'slug': b['brand_slug'], 'active': active, 'type': 'brand',
                'count': b['product_count']}

    def _cat_btn(c, active=False):
        return {'name': f"{c['category_name']} ({format_count(c['product_count'])})",
                'slug': c['category_slug'], 'active': active, 'type': 'category',
                'count': c['product_count']}

    def _sub_btn(s, active=False):
        return {'name': f"{s['sub_category_name']} ({format_count(s['product_count'])})",
                'slug': s['sub_category_slug'], 'active': active, 'type': 'sub_category',
                'count': s['product_count'],
                'parent_slug': s['category__category_slug'],
                'parent_name': s['category__category_name']}

    ab  = [b for b in brands         if b['product_count'] > 0]
    ac  = [c for c in categories     if c['product_count'] > 0]
    as_ = [s for s in sub_categories if s['product_count'] > 0]

    if filter_slug in ('all', '', None):
        buttons += [
            {'name': f"Brands ({len(brands)})",                'slug': 'brands',         'active': False, 'type': 'brands',         'count': len(brands)},
            {'name': f"Categories ({len(categories)})",        'slug': 'categories',     'active': False, 'type': 'categories',     'count': len(categories)},
            {'name': f"SubCategories ({len(sub_categories)})", 'slug': 'sub_categories', 'active': False, 'type': 'sub_categories', 'count': len(sub_categories)},
        ]
        buttons += [_brand_btn(b) for b in ab[:8]]
        buttons += [_cat_btn(c)   for c in ac[:8]]
        buttons += [_sub_btn(s)   for s in as_[:6]]

    elif filter_slug == 'brands':
        buttons.append({'name': f"Brands ({len(brands)})", 'slug': 'brands', 'active': True, 'type': 'brands', 'count': len(brands)})
        buttons += [_brand_btn(b) for b in ab[:20]]

    elif filter_slug == 'categories':
        buttons.append({'name': f"Categories ({len(categories)})", 'slug': 'categories', 'active': True, 'type': 'categories', 'count': len(categories)})
        buttons += [_cat_btn(c) for c in ac[:20]]

    elif filter_slug == 'sub_categories':
        buttons.append({'name': f"SubCategories ({len(sub_categories)})", 'slug': 'sub_categories', 'active': True, 'type': 'sub_categories', 'count': len(sub_categories)})
        buttons += [_sub_btn(s) for s in as_[:20]]

    elif active_filter_type == 'brand':
        buttons.append({'name': f"Brands ({len(brands)})", 'slug': 'brands', 'active': False, 'type': 'brands', 'count': len(brands)})
        current = _find_in_list(brands, 'brand_slug', filter_slug)
        if current:
            buttons.append(_brand_btn(current, active=True))
        buttons += [_brand_btn(b) for b in ab if b['brand_slug'] != filter_slug][:10]

    elif active_filter_type == 'category':
        buttons.append({'name': f"Categories ({len(categories)})", 'slug': 'categories', 'active': False, 'type': 'categories', 'count': len(categories)})
        slug_map = {c['category_slug']: c for c in categories}
        current  = slug_map.get(filter_slug)
        if current:
            buttons.append(_cat_btn(current, active=True))
            children = [c for c in categories
                        if c['path'].startswith(current['path'] + '/')
                        and c['level'] == current['level'] + 1
                        and c['product_count'] > 0]
            if children:
                buttons += [_cat_btn(c) for c in children[:8]]
            else:
                ppath    = current['path'].rsplit('/', 1)[0]
                siblings = [c for c in categories
                            if c['path'].rsplit('/', 1)[0] == ppath
                            and c['category_slug'] != filter_slug
                            and c['product_count'] > 0]
                buttons += [_cat_btn(c) for c in siblings[:10]]
            cat_subs = [s for s in as_ if s['category__category_slug'] == filter_slug]
            if cat_subs:
                buttons += [_sub_btn(s) for s in cat_subs[:8]]

    elif active_filter_type == 'sub_category':
        slug_map = {s['sub_category_slug']: s for s in sub_categories}
        current  = slug_map.get(filter_slug)
        if current:
            buttons.append({'name': current['category__category_name'],
                            'slug': current['category__category_slug'],
                            'active': False, 'type': 'category', 'count': 0})
            buttons.append(_sub_btn(current, active=True))
            siblings = [s for s in as_
                        if s['category__category_slug'] == current['category__category_slug']
                        and s['sub_category_slug'] != filter_slug]
            buttons += [_sub_btn(s) for s in siblings[:10]]

    cache.set(cache_key, buttons, TTL_FILTER_BUTTONS)
    return buttons


def _find_in_list(lst: list, key: str, value) -> dict | None:
    for item in lst:
        if item[key] == value:
            return item
    return None


# ─────────────────────────────────────────────────────────────────────
# Product formatter
# ─────────────────────────────────────────────────────────────────────

def _format_products(product_list, query='', dealer_counts: dict | None = None):
    """
    Format a list of ORM Product instances into template-ready dicts.

    FIX-4: accepts pre-fetched dealer_counts dict {dealer_id: count}
           to avoid an N+1 query for seller_total_products.
    FIX-7: emits 'in_stock' key (was 'is_in_stock') so the template
           {% if product.in_stock %} badge renders correctly.
    """
    if dealer_counts is None:
        dealer_counts = {}

    keywords  = [w for w in query.split() if w][:10]
    formatted = []

    for product in product_list:
        seller_name        = 'Seller'
        seller_photo_url   = '/static/defaults/default-profile-picture.png'
        seller_verified    = False
        seller_profile_url = '#'
        seller_views       = 0
        seller_followers   = 0

        try:
            profile            = product.dealer.profileinfo
            seller_name        = profile.full_name
            seller_photo_url   = profile.get_profile_photo_url()
            seller_verified    = profile.is_verified
            seller_profile_url = profile.profile_url
            seller_views       = profile.profile_views
            seller_followers   = profile.follower_count
        except Exception:
            if product.dealer:
                seller_name = getattr(product.dealer, 'email_or_phone', 'Seller')

        # FIX-4: use pre-fetched count instead of per-product DB call
        seller_total_products = dealer_counts.get(product.dealer_id, 0)

        stock        = product.stock
        threshold    = product.low_stock_threshold
        is_in_stock  = stock > 0
        is_low_stock = 0 < stock <= threshold

        if stock == 0:
            stock_badge  = 'Out of Stock'
            stock_class  = 'out-of-stock'
            stock_status = 'Out of Stock'
        elif is_low_stock:
            stock_badge  = f'Only {stock} left'
            stock_class  = 'low-stock'
            stock_status = 'Low Stock'
        else:
            stock_badge  = None
            stock_class  = 'in-stock'
            stock_status = 'In Stock'

        discount_pct   = product.discount_percentage or 0
        discount_badge = f'{int(discount_pct)}% OFF' if discount_pct > 0 else None
        final_price    = product.final_price or product.selling_price

        def highlight(text):
            if not text or not keywords:
                return escape(text or '')
            result = escape(text)
            for word in keywords:
                pattern = re.compile(re.escape(escape(word)), re.IGNORECASE)
                result  = pattern.sub(
                    lambda m: f'<mark class="highlight">{m.group()}</mark>',
                    result,
                )
            return result

        sub_cat           = product.sub_category
        sub_category_name = sub_cat.sub_category_name if sub_cat else None
        sub_category_slug = sub_cat.sub_category_slug if sub_cat else None
        brand             = product.brand
        category          = product.category

        formatted.append({
            'id':   product.pk,
            # FIX-6: always a string so `uuid in wishlisted_ids` works in template
            'uuid': str(product.product_id),
            'slug': product.slug,
            'sku':  product.sku,

            'title':                    product.product_title or '',
            'product_name':             product.product_name,
            'highlighted_title':        highlight(product.product_title),
            'highlighted_product_name': highlight(product.product_name),
            'short_description':        product.short_description or '',

            'brand_price':         format_price(product.brand_price) if product.brand_price else None,
            'original_price':      format_price(product.selling_price),
            'final_price':         format_price(final_price),
            'discount_percentage': discount_pct,
            'discount_badge':      discount_badge,
            'on_sale':             discount_pct > 0,

            'image':     product.image_url,
            'video_url': product.video_url,

            'seller_name':          seller_name,
            'seller_photo':         seller_photo_url,
            'seller_verified':      seller_verified,
            'seller_profile_url':   seller_profile_url,
            'seller_views':         format_views(seller_views),
            'seller_followers':     format_count(seller_followers),
            'seller_username':      product.dealer.email_or_phone if product.dealer else '',
            'seller_total_products': seller_total_products,

            'views':          format_views(product.view_count),
            'views_raw':      product.view_count,
            'rating':         float(product.rating_average or 0),
            'review_count':   product.review_count,
            'total_sales':    product.total_sales,
            'wishlist_count': product.wishlist_count,

            'stock':        stock,
            'stock_count':  format_count(stock),
            'stock_status': stock_status,
            'stock_badge':  stock_badge,
            'stock_class':  stock_class,
            # FIX-7: key renamed from 'is_in_stock' → 'in_stock' to match
            #         the {% if product.in_stock %} check in the template.
            'in_stock':     is_in_stock,
            'is_low_stock': is_low_stock,

            'brand':         brand.brand_name       if brand    else 'No Brand',
            'brand_slug':    brand.brand_slug       if brand    else None,
            'brand_logo':    brand.logo_url         if brand    else None,
            'category':      category.category_name if category else 'Uncategorized',
            'category_slug': category.category_slug if category else None,
            'sub_category':      sub_category_name,
            'sub_category_slug': sub_category_slug,

            'is_featured':   product.is_featured,
            'is_verified':   product.is_verified,
            'is_trending':   product.is_trending,
            'free_shipping': product.free_shipping,
            'condition':     product.get_product_condition_display(),

            'product_url': product.product_url,

            # Required by feed_algorithm.rank_and_diversify()
            'created_at': product.created_at,
            'dealer_id':  product.dealer_id,
            'age_days':   round(
                (timezone.now() - product.created_at).total_seconds() / 86400, 1
            ) if product.created_at else None,
        })

    return formatted


# ─────────────────────────────────────────────────────────────────────
# Formatting helpers
# ─────────────────────────────────────────────────────────────────────

def format_count(count) -> str:
    try:
        n = int(count)
        if n >= 1_000_000: return f'{n / 1_000_000:.1f}M'.replace('.0M', 'M')
        if n >= 1_000:     return f'{n / 1_000:.1f}k'.replace('.0k', 'k')
        return str(n)
    except (ValueError, TypeError):
        return '0'


def format_views(views) -> str:
    try:
        n = int(views)
        if n >= 1_000_000: return f'{n / 1_000_000:.1f}M'.replace('.0M', 'M')
        if n >= 1_000:     return f'{n / 1_000:.1f}K'.replace('.0K', 'K')
        return str(n)
    except (ValueError, TypeError):
        return '0'


def format_price(price) -> str:
    try:
        if price is None:
            return '0 Tk'
        from decimal import Decimal
        d = Decimal(str(price))
        if d == d.to_integral_value():
            return f'{int(d):,} Tk'
        return f'{d:,.2f} Tk'
    except (ValueError, TypeError):
        return '0 Tk'


# ═════════════════════════════════════════════════════════════════════
# ██  ENGINE VIEW  (authenticated stub)
# ═════════════════════════════════════════════════════════════════════

@login_required
def EngineView(request):
    context = {}
    return render(request, 'business/engine.html', context)