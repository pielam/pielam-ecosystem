from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse, Http404
from django.db.models import Q, Prefetch
from django.core.paginator import Paginator
from django.views import View
from django.views.generic import DetailView
from django.utils import timezone
from django.contrib import messages
from django.core.cache import cache
import uuid

from apps.ponno.models.product import Product, ProductView
from apps.ponno.models.category import Category
from apps.ponno.models.brand import Brand


def ProductDetail(request, slug):
    """
    Enhanced Product Detail View with optimized queries and analytics
    """
    
    # Optimized query with select_related and prefetch_related
    try:
        product = Product.objects.select_related(
            'brand',
            'category',
            'dealer',
            'dealer__profileinfo'
        ).prefetch_related(
            'dealer__products'
        ).get(
            slug=slug,
            is_active=True,
            deleted_at__isnull=True
        )
    except Product.DoesNotExist:
        raise Http404("Product not found or has been removed")
    
    # Increment view count asynchronously (don't block the request)
    product.increment_view_count(save=True)
    
    # Get active categories (cached for 1 hour)
    categories_cache_key = 'active_categories_list'
    categories = cache.get(categories_cache_key)
    
    if categories is None:
        categories = Category.objects.filter(
            is_active=True,
            deleted_at__isnull=True
        ).order_by('display_order', 'category_name')[:20]
        cache.set(categories_cache_key, categories, 3600)  # Cache for 1 hour
    
    # Get related products from same category (excluding current product)
    related_products = Product.objects.filter(
        category=product.category,
        is_active=True,
        deleted_at__isnull=True
    ).exclude(
        pk=product.pk
    ).select_related(
        'brand', 'category'
    ).order_by('-view_count')[:6]
    
    # Get other products from same dealer
    dealer_products = Product.objects.filter(
        dealer=product.dealer,
        is_active=True,
        deleted_at__isnull=True
    ).exclude(
        pk=product.pk
    ).select_related(
        'brand', 'category'
    ).order_by('-created_at')[:6]
    
    # Check if user has recently viewed this product (for analytics)
    # Check if user has recently viewed this product (for analytics)
    if request.user.is_authenticated:
        # Record in ProductView model (used by profile Recently Viewed tab)
        ProductView.record(user=request.user, product=product)

        # Keep session history as well
        viewed_products = request.session.get('viewed_products', [])
        if str(product.product_id) not in viewed_products:
            viewed_products.insert(0, str(product.product_id))
            viewed_products = viewed_products[:10]
            request.session['viewed_products'] = viewed_products
    
    # Calculate price savings
    if product.brand_price and product.selling_price:
        savings = product.brand_price - product.selling_price
        savings_percentage = (savings / product.brand_price * 100) if product.brand_price > 0 else 0
    else:
        savings = 0
        savings_percentage = 0
    
    # Prepare structured data for SEO (JSON-LD)
    structured_data = {
        "@context": "https://schema.org/",
        "@type": "Product",
        "name": product.product_name,
        "image": request.build_absolute_uri(product.image.url) if product.image else "",
        "description": product.short_description or product.description,
        "sku": product.sku,
        "brand": {
            "@type": "Brand",
            "name": product.brand.brand_name if product.brand else "Unknown"
        },
        "offers": {
            "@type": "Offer",
            "url": request.build_absolute_uri(),
            "priceCurrency": product.currency,
            "price": str(product.selling_price),
            "priceValidUntil": (timezone.now() + timezone.timedelta(days=30)).strftime("%Y-%m-%d"),
            "itemCondition": "https://schema.org/NewCondition",
            "availability": "https://schema.org/InStock" if product.stock > 0 else "https://schema.org/OutOfStock",
            "seller": {
                "@type": "Organization",
                "name": product.dealer.profileinfo.business_name if product.dealer.profileinfo.business_name else product.dealer.profileinfo.profile_name
            }
        },
        "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": str(product.rating_average),
            "reviewCount": str(product.review_count)
        } if product.review_count > 0 else None
    }
    
    # Build context
    context = {
        'product': product,
        'categories': categories,
        'related_products': related_products,
        'dealer_products': dealer_products,
        'current_year': timezone.now().year,
        'savings': savings,
        'savings_percentage': round(savings_percentage, 1),
        'structured_data': structured_data,
        
        # Meta tags for SEO
        'meta_title': product.meta_title or f"{product.product_name} - {product.brand.brand_name if product.brand else 'PIELAM'}",
        'meta_description': product.meta_description or product.short_description or product.description[:160],
        'meta_keywords': product.meta_keywords or f"{product.product_name}, {product.brand.brand_name if product.brand else ''}, {product.category.category_name if product.category else ''}",
        
        # Open Graph tags for social sharing
        'og_title': product.product_name,
        'og_description': product.short_description or product.description[:200],
        'og_image': request.build_absolute_uri(product.image.url) if product.image else "",
        'og_url': request.build_absolute_uri(),
        
        # Dealer contact info (respecting privacy settings)
        'show_dealer_phone': product.dealer.profileinfo.show_phone if hasattr(product.dealer, 'profileinfo') else False,
        'show_dealer_email': product.dealer.profileinfo.show_email if hasattr(product.dealer, 'profileinfo') else False,
    }
    
    return render(request, 'ponno/product_detail.html', context)


# Alternative Class-Based View (CBV) approach
class ProductDetailView(DetailView):
    """
    Class-based view alternative for product detail
    """
    model = Product
    template_name = 'ponno/product_detail.html'
    context_object_name = 'product'
    slug_field = 'slug'
    
    def get_queryset(self):
        """Optimize queries"""
        return Product.objects.select_related(
            'brand',
            'category',
            'dealer',
            'dealer__profileinfo'
        ).prefetch_related(
            'dealer__products'
        ).filter(
            is_active=True,
            deleted_at__isnull=True
        )
    
    def get_object(self, queryset=None):
        """Get object and increment view count"""
        obj = super().get_object(queryset)
        obj.increment_view_count(save=True)
        return obj
    
    def get_context_data(self, **kwargs):
        """Add additional context"""
        context = super().get_context_data(**kwargs)
        product = self.object
        
        # Add categories (cached)
        categories_cache_key = 'active_categories_list'
        categories = cache.get(categories_cache_key)
        
        if categories is None:
            categories = Category.objects.filter(
                is_active=True,
                deleted_at__isnull=True
            ).order_by('display_order', 'category_name')[:20]
            cache.set(categories_cache_key, categories, 3600)
        
        context['categories'] = categories
        context['current_year'] = timezone.now().year
        
        # Related products
        context['related_products'] = Product.objects.filter(
            category=product.category,
            is_active=True,
            deleted_at__isnull=True
        ).exclude(pk=product.pk).select_related('brand', 'category')[:6]
        
        # Dealer products
        context['dealer_products'] = Product.objects.filter(
            dealer=product.dealer,
            is_active=True,
            deleted_at__isnull=True
        ).exclude(pk=product.pk).select_related('brand', 'category')[:6]
        
        # Calculate savings
        if product.brand_price and product.selling_price:
            savings = product.brand_price - product.selling_price
            savings_percentage = (savings / product.brand_price * 100) if product.brand_price > 0 else 0
        else:
            savings = 0
            savings_percentage = 0
        
        context['savings'] = savings
        context['savings_percentage'] = round(savings_percentage, 1)
        
        # SEO meta tags
        context['meta_title'] = product.meta_title or f"{product.product_name} - {product.brand.brand_name if product.brand else 'PIELAM'}"
        context['meta_description'] = product.meta_description or product.short_description or product.description[:160]
        
        return context